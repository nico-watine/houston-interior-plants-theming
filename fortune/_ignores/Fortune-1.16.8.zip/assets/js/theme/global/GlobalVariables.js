import $ from 'jquery';

// expose jQuery to window scope for jQuery plugins and third-party scripts
window.$ = $;
window.jQuery = $;