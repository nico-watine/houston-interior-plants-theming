import PageManager from '../PageManager';

export default class Compare extends PageManager {
  constructor() {
    super();

  }

}
